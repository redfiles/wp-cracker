If you can't work with this tool properly. Follow below steps...

1. First, download python latest version from python.org ......
2. After installing python, type following commands on your CMD or Terminal....
	pip install requests
	pip install pyfiglet
	pip install json
	pip install termcolor
	pip install bs4
3. Now run following command on your cmd. (Note: Go to wpcracker.py contained folder on your cmd...) 
	python wpcracker.py

If you have any question, chat with telegram.
Telegram username : @dom_black_hat

-----------------------------------------------------------
~ Don't remove files in res folder..... 
~ Also, you can copy and paste usernames to "uname.txt" file. But, don't change the name of that file...
~ You can copy and paste passwords to "pass.txt" file. Don't rename....
~ Also, you can replace username file and password file with another 2 files with same names.

Good Luck !